=== FORMA × CINE LAB - APK Project ===

Para compilar el APK en tu celular:

1. Instala AIDE (Android IDE) desde Play Store
2. Crea un nuevo proyecto: "Android App -> Blank App"
3. Reemplaza los archivos con estos:

   - AndroidManifest.xml -> app/src/main/AndroidManifest.xml
   - java/com/formacine/lab/MainActivity.java -> app/src/main/java/com/formacine/lab/MainActivity.java
   - res/layout/activity_main.xml -> app/src/main/res/layout/activity_main.xml
   - res/values/strings.xml -> app/src/main/res/values/strings.xml
   - res/values/styles.xml -> app/src/main/res/values/styles.xml
   - assets/www/ -> app/src/main/assets/www/ (todo el contenido web)

4. En AIDE, toca "Run" -> "Build APK"
5. El APK se genera en app/build/outputs/apk/debug/

Nota: Los archivos index.js e index.css son los que me pasaste.
El index.html los carga localmente.
